
func initializeGame() {
    // create a 4x4 game board and displays it
    var score = 0 // initializes the scare variable and displays it
}

func playerInteraction(sqaure1:Int , sqaure2:Int) -> Bool //square1 and sqaure2
{
    //this method is used to make the main funcionality of the game
    //for instance if the user swipes the other fruits shift due ot this function
    //main coding behind the user interaction of the game
    return true
}

func playGame() {
    while true //true = game is not over
    {
        //while loop that makes sure the user keeps
        //playing until the game is over
    }
}

func checkAndRemoveMatches() {
    while true //
    {
        //checks to see if there are matches
        //shifts the caqndies around when there is a match
        //adds in new randomaized candies when there are matches
    }
}

func displayGameOver() {
    //displays the game over message
    //shows the final a score
    //gives the user a chance to
}

// Entry point
initializeGame()
playGame()
displayGameOver()
