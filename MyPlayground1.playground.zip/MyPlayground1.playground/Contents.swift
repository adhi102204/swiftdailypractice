//The Basics

var lynk = "lynk"
let randnum: Int


if lynk == "lynk" {
    randnum = 100
} else {
    randnum = 10
}

let minimum = UInt8.min
let maximum = UInt8.max

let adhi = 0.46
let sidhu = 3
let senthil = Double(sidhu) + adhi

let swiftClass = true
if swiftClass {
    print("we are in the swift class")
}
else {
    print("we are not in the swift class")
}


let bestrappers = ("playboi carti", "lil uzi vert")
let (bestrapper1, bestrapper2) = bestrappers
print("the top 2 artists are \(bestrappers.1) and \(bestrappers.0)")

let bday = "2204"
let bdayint = Int(bday)


if bdayint != nil {
    print("convertedNumber contains some integer value.")
}

if let num1 = Int("7") {
    if let num2 = Int("56") {
        if num1 < num2 && num2 < 100 {
            print("\(num1) < \(num2) < 100")
        }
    }
}


let strnum = "1234"
let numnum = Int(strnum)
let numm = numnum!
// numm is unwrapped


//Basic Operations

var michaeljordan = 23
var kobebryant = 24
kobebryant = michaeljordan

print(kobebryant)


var (kbryant, mjordan) = (24, 23)
print(kbryant)
print(mjordan)

if mjordan == kbryant
{
    print("michael jordan is the best basketball player")
}
else
{
    print("michael jordan ain't that great")
}


var seven = 3 + 4
var ten = 5 * 2

var helloWorld = "hello " + "world"
var twenty = 0


twenty = 3
twenty += 17

if mjordan > kbryant
{
    print("michael jordan is the best basketball player")
}
else
{
    print("michael jordan ain't that great")
}

if mjordan < kbryant
{
    print("michael jordan is the best basketball player")
}
else
{
    print("michael jordan ain't that great")
}


var verizon = true
var tmobile = false

print(verizon && tmobile)
print(verizon || tmobile)

// Strings and Characters

let myString = "I am him"

let myBigString = """
 Hi Sophia and Jake, I hope you are doing well. I am writing to follow up on the status of my recent interview/application for the Maps Business Analyst position at Apple. I appreciate the opportunity and am enthusiastic about the possibility of joining the Maps team. Could you please provide an update on the timeline for the next steps in the hiring process? Thank you for your time and consideration. I look forward to hearing from you soon. Thanks, Adhithyaa Senthil
"""

var famousquote = "\"Never Give Up\""

famousquote += " by me"


for char in "michael"
{
    print(char)
}

var mj = "Michael Jordan"

print("the best basketball player is \(mj)")

print("\(mj) has \(mj.count) characters")

print(mj.startIndex)
print(mj.endIndex)

// Collection Types

var someInt: [Int] = []

someInt.append(22)
print(someInt)
someInt = []
print(someInt)

var tripledouble = Array(repeating: 10.0, count: 3)
print(tripledouble)

print(tripledouble.count)
print(tripledouble.isEmpty)

var mylist: [String] = ["hey", "hello", "wassup"]
var firstgreeting:String = mylist[0]
print(mylist)
print(firstgreeting)

mylist += ["yello", "whats up", "comeback season"]

var hello = mylist.remove(at: 0)
print(hello)
print(mylist)

for item in mylist
{
    print(item)
}


var my_dict = [1:"Kobe Byant", 2:"Michael Jordan", 3:"Lebron James"]
print(my_dict)

//Control flow

for i in 0...6
{
    print("wassup")
}


for i in 0..<6
{
    print("come back")
}

for interval in stride(from: 0, through: 100, by: 10)
{
    print(interval)
}

var x = 0

while x != 3
{
    print("FEIN!!!")
    x += 1
}

repeat
{
    print("FEIN!!!")
    x+=1
} while x != 6
            
if x == 6
{
    print("FEIN!!!")
}

let somelyric = "FEINN!!!"
switch somelyric{
case "Fein":
    print("not good enough")
case "FEIN":
    print("still not good enough")
case "FEINN!!!":
    print("Yessirr")
default:
    print("sum else")
}

//functions

func greet(_ person:String) -> String
{
    return "hello \(person) how are you?"
}
print(greet("Adhithyaa"))

func myCalcFunc(_ amt:Double, _ taxrt:Double, _ ppl:Double) -> Double
{
    var eachowes = (amt + (amt * (taxrt/100)))/3
    return eachowes
    
}
var finalowedamt = myCalcFunc(15, 8.33, 3)
print(finalowedamt)

func greeting(_ person:String)
{
    print("hello \(person) how are you?")
}
greeting("Adhithyaa")

//Closures

var names = ["Adhi", "Samay", "Om", "Joshua", "Vishal"]
var reversedNames = names.sorted(by: { (s1: String, s2: String) -> Bool in
    return s1 > s2
})
print(reversedNames)

enum aitnames
{
    case adhi
    case samay
    case vishal
    case joshua
}
var theidolofait = aitnames.adhi
switch theidolofait {
case .adhi:
    print("adhi is him")
case .samay:
    print("FEINN!!!")
case .joshua:
    print("FEINN!!!")
case .vishal:
    print("FEINN!!!")
}


//Structures

struct Human
{
    var weight:Double = 0
    var gpa:Double = 0.0
    var major:String = "Undeclared"
    func hey()
    {
        print("hi")
    }
}

var bradpitt = Human()
bradpitt.weight = 150.0
bradpitt.gpa = 2.3
bradpitt.major = "communications"
print("Here is some info on Brad Pitt: He is a \(bradpitt.major) major weighing around \(bradpitt.weight) pounds with a GPA of \(bradpitt.gpa)")



print(bradpitt.major)
//major is a stored property

bradpitt.hey()
// this is a method

//another example of prepteries ansd methods

struct Car
{
    var type:String = "Tesla"
    var speed:Double = 120
    func driveCar()
    {
        print("I am driving rn")
    }
}

var myCar = Car()
//properties
print(myCar.type)
print(myCar.speed)
//methods
myCar.driveCar()

//subripts use

var numberOfRings = ["MJ": 6,"KB":5,"LBJ":4]
numberOfRings["KAJ"] = 6
print(numberOfRings)

// inheritance


class human
{
    var weight:Double = 0
    func hey()
    {
        print("hi")
    }
}

class student: human
{
    var gpa:Double = 0.0
    var major:String = "Undeclared"
}

class teacher: human
{
    var numofstudents:Double = 0.0
    var dept:String = "TBD"
}

//initialization

struct Rapper
{
    var numofhits:Int
    init(){
        numofhits = 0
    }
}
var rapper = Rapper()
print("when a rapper starts out he has \(rapper.numofhits) hits")

struct Rapperhits
{
    let platinum, gold: String
    init(platinum: String, gold: String) {
        self.platinum = platinum
        self.gold = gold
    }
}

var Drake = Rapperhits(platinum: "17", gold: "124")
print(Drake.platinum)
print(Drake.gold)
