import Foundation

//Data Types

//Strings
print ("hi how are you")

//integers

var mynum = 22
print(mynum)

//double

var newmynum = 22.5
print(newmynum)

//boolean
var trust = true
var donttrust = false

var hello:String = "wassssuuuuppp"


var myNum: Int = 1628

myNum += 1
print(myNum)

let myConst:String = "you can't change this"

print(myConst)

var a:Double = 5.3
var b:Double = 4.2

var c = ceil(a)
print(c)
c = floor(b)
print(c)





//Functions

func myCalcFunc(_ amt:Double, _ taxrt:Double, _ ppl:Double) -> Double
{
    var eachowes = (amt + (amt * (taxrt/100)))/3
    return round (eachowes * 100)/100
    
}
var finalowedamt = myCalcFunc(15, 8.33, 3)
print(finalowedamt)


struct ChatView
{
    //variable and conditions: properties
    var msg:String = "hi there" //stored prpoerties
    var msgWithPrefix:String
    {
        return msg + "i ain't tryna talk to ya"
    }
    
    //UI code: View Code
    
    
    
    //fucntions: EVENTS
    func sentChat()
    {
        //get the code to send chat
        print(msg)
        print(msgWithPrefix)
    }
    func deleteChat()
    {
        //get the code to delete chat
        print(msg)
        print(msgWithPrefix)
    }
}


//Day 2

struct DBmanager
{
    func saveData(data:String) -> Bool
    {
        return true
    }
}


struct NewChatView
{
    var message = "wassup"
    
    
    func sendChat()
    {
        //print(message)
        var dbManager:DBmanager = DBmanager()
        let success = dbManager.saveData(data: "Hello")
    }
}
var newA:NewChatView = NewChatView()
newA.sendChat()



var newB:NewChatView = NewChatView()
newB.message = "heyyy"
newB.sendChat()


let r = true
let e = false

if r || e
{
    print("FEINNNN!!!!!")
}
else
{
    print("heyy")
}
